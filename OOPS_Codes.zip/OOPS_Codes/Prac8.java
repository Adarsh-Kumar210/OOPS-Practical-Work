public class Prac8 {

    public static void main(String[] args) {

        // 1. No-argument Constructor
        Product p1 = new Product();

        // 2. Constructor with product name only
        Product p2 = new Product("Laptop");

        // 3. Constructor with product name and price
        Product p3 = new Product("Mobile", 15000);

        // 4. Constructor with all three fields
        Product p4 = new Product("Headphones", 2000, 3);

        // Displaying all products
        System.out.println("No-Argument Constructor:");
        p1.display();

        System.out.println("\nName Only Constructor:");
        p2.display();

        System.out.println("\nName and Price Constructor:");
        p3.display();

        System.out.println("\nAll Arguments Constructor:");
        p4.display();
    }
}

class Product {

    // Instance variables
    String name;
    double price;
    int quantity;

    // 1. No-argument Constructor
    Product() {
        name = "Unknown";
        price = 0;
        quantity = 0;
    }

    // 2. Constructor with product name
    Product(String name) {
        this.name = name;
        price = 0;
        quantity = 0;
    }

    // 3. Constructor with name and price
    Product(String name, double price) {
        this.name = name;
        this.price = price;
        quantity = 1;
    }

    // 4. Constructor with all three fields
    Product(String name, double price, int quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    // Method to calculate total cost
    double calculateTotalCost() {
        return price * quantity;
    }

    // Method to display product details
    void display() {
        System.out.println("Product Name: " + name);
        System.out.println("Price: Rs. " + price);
        System.out.println("Quantity: " + quantity);
        System.out.println("Total Cost: Rs. " + calculateTotalCost());
    }
}
