public class Prac7 {

    public static void main(String[] args) {

        // Creating an object
        Student s1 = new Student();

        // Using the object
        s1.display();

        // Removing reference
        s1 = null;

        System.out.println("Object reference removed.");

        // Requesting garbage collection
        System.gc();

        System.out.println("Garbage collection requested.");

    }
}

class Student {

    // Constructor
    Student() {
        System.out.println("Student object created.");
    }

    // Method
    void display() {
        System.out.println("Student object is being used.");
    }

    // Finalize method (for demonstration only)
    @Override
    protected void finalize() {
        System.out.println("Garbage collector is cleaning the object.");
    }
}
