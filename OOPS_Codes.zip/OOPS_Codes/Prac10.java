public class Prac10 {

    public static void main(String[] args) {

        // Creating BankAccount object
        BankAccount b1 = new BankAccount("Aman", 12345, 5000);

        // Displaying initial details
        System.out.println("Initial Account Details:");
        b1.displayDetails();

        // Valid deposit
        System.out.println("\nDepositing Rs. 2000");
        b1.deposit(2000);

        // Invalid deposit
        System.out.println("\nDepositing Rs. -500");
        b1.deposit(-500);

        // Valid withdrawal
        System.out.println("\nWithdrawing Rs. 1000");
        b1.withdraw(1000);

        // Invalid withdrawal
        System.out.println("\nWithdrawing Rs. -200");
        b1.withdraw(-200);

        // Withdrawal greater than balance
        System.out.println("\nWithdrawing Rs. 10000");
        b1.withdraw(10000);

        // Displaying final balance
        System.out.println("\nFinal Account Details:");
        b1.displayDetails();
    }
}

class BankAccount {

    // Private instance variables
    private String accountHolder;
    private int accountNumber;
    private double balance;

    // Constructor
    BankAccount(String accountHolder, int accountNumber, double balance) {
        this.accountHolder = accountHolder;
        this.accountNumber = accountNumber;

        if (balance >= 0) {
            this.balance = balance;
        } else {
            this.balance = 0;
        }
    }

    // Getters
    public String getAccountHolder() {
        return accountHolder;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    // Deposit method
    public void deposit(double amount) {

        if (amount > 0) {
            balance = balance + amount;
            System.out.println("Deposit successful.");
        } else {
            System.out.println("Invalid deposit amount!");
        }
    }

    // Withdraw method
    public void withdraw(double amount) {

        if (amount <= 0) {
            System.out.println("Invalid withdrawal amount!");
        } else if (amount > balance) {
            System.out.println("Insufficient balance!");
        } else {
            balance = balance - amount;
            System.out.println("Withdrawal successful.");
        }
    }

    // Display account details
    public void displayDetails() {
        System.out.println("Account Holder: " + getAccountHolder());
        System.out.println("Account Number: " + getAccountNumber());
        System.out.println("Balance: Rs. " + getBalance());
    }
}