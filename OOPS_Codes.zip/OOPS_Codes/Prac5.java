public class Prac5 {

    public static void main(String[] args) {

        // Creating two ComplexNumber objects
        ComplexNumber c1 = new ComplexNumber(5, 3);
        ComplexNumber c2 = new ComplexNumber(2, 4);

        // Displaying original complex numbers
        System.out.println("First Complex Number:");
        c1.display();

        System.out.println("Second Complex Number:");
        c2.display();

        // Adding two complex numbers
        ComplexNumber result = c1.add(c2);

        // Displaying result
        System.out.println("Sum of Complex Numbers:");
        result.display();
    }
}

// ComplexNumber class
class ComplexNumber {

    // Instance variables
    int real;
    int imaginary;

    // Constructor
    ComplexNumber(int real, int imaginary) {
        this.real = real;
        this.imaginary = imaginary;
    }

    // Method to add two complex numbers
    ComplexNumber add(ComplexNumber c) {

        int r = this.real + c.real;
        int i = this.imaginary + c.imaginary;

        return new ComplexNumber(r, i);
    }

    // Method to display complex number
    void display() {

        if (imaginary >= 0) {
            System.out.println(real + " + " + imaginary + "i");
        } else {
            System.out.println(real + " - " + (-imaginary) + "i");
        }
    }
}
