public class Prac4 {

    public static void main(String[] args) {

        // Method Overloading
        System.out.println("METHOD OVERLOADING");

        Calculator c = new Calculator();

        System.out.println("Addition of 2 integers: " + c.add(10, 20));
        System.out.println("Addition of 3 integers: " + c.add(10, 20, 30));
        System.out.println("Addition of 2 double values: " + c.add(10.5, 20.5));

        // Method Overriding
        System.out.println("\nMETHOD OVERRIDING");

        Employee e;

        e = new FullTimeEmployee();
        e.calculatePay();

        e = new PartTimeEmployee();
        e.calculatePay();
    }
}

// Calculator class for Method Overloading
class Calculator {

    // Adding two integers
    int add(int a, int b) {
        return a + b;
    }

    // Adding three integers
    int add(int a, int b, int c) {
        return a + b + c;
    }

    // Adding two double values
    double add(double a, double b) {
        return a + b;
    }
}

// Base class
class Employee {

    void calculatePay() {
        System.out.println("Calculating employee salary");
    }
}

// First derived class
class FullTimeEmployee extends Employee {

    @Override
    void calculatePay() {
        int salary = 50000;
        System.out.println("Full Time Employee Salary: " + salary);
    }
}

// Second derived class
class PartTimeEmployee extends Employee {

    @Override
    void calculatePay() {
        int hours = 80;
        int rate = 200;

        int salary = hours * rate;

        System.out.println("Part Time Employee Salary: " + salary);
    }
}
