public class Prac6 {
    public static void main(String[] args) {

        // 1. Default Constructor
        Book b1 = new Book();

        // 2. Parameterized Constructor
        Book b2 = new Book("Java Programming", "James Gosling", 450);

        // 3. Copy Constructor
        Book b3 = new Book(b2);

        // Displaying all objects
        System.out.println("Default Constructor:");
        b1.display();

        System.out.println("\nParameterized Constructor:");
        b2.display();

        System.out.println("\nCopy Constructor:");
        b3.display();

        // Modifying copied object
        b3.title = "Advanced Java";
        b3.price = 600;

        System.out.println("\nAfter Modifying Copied Object:");

        System.out.println("Original Book:");
        b2.display();

        System.out.println("Copied Book:");
        b3.display();
    }
}

class Book {

    // Instance variables
    String title;
    String author;
    double price;

    // 1. No-argument Constructor
    Book() {
        title = "Unknown";
        author = "Unknown";
        price = 0;
    }

    // 2. Parameterized Constructor
    Book(String title, String author, double price) {
        this.title = title;
        this.author = author;
        this.price = price;
    }

    // 3. Copy Constructor
    Book(Book b) {
        this.title = b.title;
        this.author = b.author;
        this.price = b.price;
    }

    // Method to display book details
    void display() {
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("Price: Rs. " + price);
    }
}
