public class Prac3 {

    public static void main(String[] args) {

        // Multiple Inheritance using Interfaces
        System.out.println("MULTIPLE INHERITANCE");

        AllInOnePrinter p = new AllInOnePrinter();
        p.print();
        p.scan();

        // Hybrid Inheritance
        System.out.println("\nHYBRID INHERITANCE");

        SmartPrinter s = new SmartPrinter();
        s.deviceInfo();
        s.print();
        s.scan();
    }
}

// First Interface
interface Printable {
    void print();
}

// Second Interface
interface Scannable {
    void scan();
}

// Implementing Multiple Interfaces
class AllInOnePrinter implements Printable, Scannable {

    public void print() {
        System.out.println("Printer is printing");
    }

    public void scan() {
        System.out.println("Printer is scanning");
    }
}

// Base Class
class Device {

    void deviceInfo() {
        System.out.println("This is an electronic device");
    }
}

// Hybrid Inheritance using Class and Interfaces
class SmartPrinter extends Device implements Printable, Scannable {

    public void print() {
        System.out.println("Smart Printer is printing");
    }

    public void scan() {
        System.out.println("Smart Printer is scanning");
    }

}