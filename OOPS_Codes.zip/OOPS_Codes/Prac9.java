public class Prac9 {

    public static void main(String[] args) {

        // Creating first object using no-argument constructor
        Employee e1 = new Employee();

        // Creating second object using parameterized constructor
        Employee e2 = new Employee("Aman", 30000);

        // Creating third object
        Employee e3 = new Employee("Riya", 45000);

        // Displaying employee details
        System.out.println("Employee Details:");

        e1.display();
        e2.display();
        e3.display();

        // Displaying total employee count
        Employee.displayCount();
    }
}

class Employee {

    // Instance variables
    String name;
    double salary;

    // Static variable
    static int count = 0;

    // No-argument constructor
    Employee() {
        this("Unknown", 0);
    }

    // Parameterized constructor
    Employee(String name, double salary) {

        this.name = name;
        this.salary = salary;

        count++;
    }

    // Method to display employee details
    void display() {
        System.out.println("Name: " + this.name);
        System.out.println("Salary: Rs. " + this.salary);
        System.out.println("--------------------");
    }

    // Static method to display employee count
    static void displayCount() {
        System.out.println("Total Employees Created: " + count);
    }
}
