public class Prac1 {

    public static void main(String[] args) {

        // Creating three Student objects
        Student s1 = new Student(101, "Aman", 85, 90, 80);
        Student s2 = new Student(102, "Riya", 78, 88, 92);
        Student s3 = new Student(103, "Rahul", 90, 95, 89);

        // Displaying details
        s1.displayDetails();
        s2.displayDetails();
        s3.displayDetails();
    }
}

class Student {

    // Instance variables
    int rollNo;
    String name;
    int marks1, marks2, marks3;

    // Constructor
    Student(int rollNo, String name, int marks1, int marks2, int marks3) {
        this.rollNo = rollNo;
        this.name = name;
        this.marks1 = marks1;
        this.marks2 = marks2;
        this.marks3 = marks3;
    }

    // Calculate total marks
    int calculateTotal() {
        return marks1 + marks2 + marks3;
    }

    // Calculate percentage
    double calculatePercentage() {
        return calculateTotal() / 3.0;
    }

    // Display student details
    void displayDetails() {
        System.out.println("Roll Number: " + rollNo);
        System.out.println("Name: " + name);
        System.out.println("Total Marks: " + calculateTotal());
        System.out.println("Percentage: " + calculatePercentage() + "%");
        System.out.println("----------------------");
    }
}