
public class Prac2 {

    public static void main(String[] args) {

        // 1. Single Inheritance
        System.out.println("SINGLE INHERITANCE");
        Car c = new Car();
        c.start();
        c.drive();

        // 2. Multilevel Inheritance
        System.out.println("\nMULTILEVEL INHERITANCE");
        Manager m = new Manager();
        m.showPerson();
        m.showEmployee();
        m.showManager();

        // 3. Hierarchical Inheritance
        System.out.println("\nHIERARCHICAL INHERITANCE");

        Circle cir = new Circle();
        cir.displayShape();
        cir.calculateArea();

        Rectangle r = new Rectangle();
        r.displayShape();
        r.calculateArea();
    }
}

// Single Inheritance
class Vehicle {

    void start() {
        System.out.println("Vehicle is starting");
    }
}

class Car extends Vehicle {

    void drive() {
        System.out.println("Car is driving");
    }
}

// Multilevel Inheritance
class Person {

    void showPerson() {
        System.out.println("This is a Person");
    }
}

class Employee extends Person {

    void showEmployee() {
        System.out.println("This is an Employee");
    }
}

class Manager extends Employee {

    void showManager() {
        System.out.println("This is a Manager");
    }
}

// Hierarchical Inheritance
class Shape {

    void displayShape() {
        System.out.println("This is a Shape");
    }
}

class Circle extends Shape {

    void calculateArea() {
        double radius = 5;
        double area = 3.14 * radius * radius;
        System.out.println("Area of Circle: " + area);
    }
}

class Rectangle extends Shape {

    void calculateArea() {
        int length = 10;
        int breadth = 5;
        int area = length * breadth;
        System.out.println("Area of Rectangle: " + area);
    }
}
